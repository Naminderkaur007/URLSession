



import UIKit
import Alamofire

struct ToDoResponseModel: Codable {
    var userId: Int
    var id: Int?
    var title: String
    var completed: Bool
}


class AlamofireViewController: UIViewController,URLSessionDownloadDelegate,URLSessionTaskDelegate {

    var pdfURL: URL?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //AFRequest()
        //URLSessionPostApi()
        //URLSessionGetAPI()
       // downloadPDF()
        
    
    }
    
    ///////////////////////////////////////////////////////
    
    func AFRequest(){
        
        AF.request("http://api.plos.org/search?q=title:DNA").responseData { response in
            print(response.data)
            if let data : Data = response.data{
                do{
                    let results : SuccessResult = try JSONDecoder().decode(SuccessResult.self, from: data) as SuccessResult
                    let arDocs : [docs] = (results.response?.docs)!
                    
                    //var fullaray : [docs] = ["jkl"]
                    print(arDocs)
                    
                    let arAutorDis : [String] = arDocs[0].author_display!
                    let abstract : [String] = arDocs[0].abstract!
                    print(arAutorDis[0])
                    
                    for result1 in (results.response?.docs)!{
                        
                        let arAutorDis : [String] = result1.author_display!
                        let abstract : [String] = result1.abstract!
                        print(arAutorDis[0])
                        print(abstract[0])
                                               
                        
                        
                    }
                }catch{ }
            }
        }
    }
    
    func URLSessionPostApi(){
        
             //request create
              let url = URL(string: "https://jsonplaceholder.typicode.com/todos")
               guard let requestUrl = url else { fatalError() }
               var request = URLRequest(url: requestUrl)
               request.httpMethod = "POST"
               // Set HTTP Request Header
               request.setValue("application/json", forHTTPHeaderField: "Accept")
               request.setValue("application/json", forHTTPHeaderField: "Content-Type")
             
               
               //jsonData to send
               let newTodoItem = ToDoResponseModel(userId: 300, title: "Urgent task 2", completed: true)
               let jsonData = try? JSONEncoder().encode(newTodoItem)
               request.httpBody = jsonData
               
               
               //this will hit the request
               let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
                       
                       if let error = error {
                           print("Error took place \(error)")
                           return
                       }
                       guard let data = data else {return}
                       do{
                           print("result",response)
                           //jsondecoder get the data
                           let todoItemModel = try JSONDecoder().decode(ToDoResponseModel.self, from: data)
                           print("Response data:\n \(todoItemModel)")
                           print("todoItemModel Title: \(todoItemModel.title)")
                           print("todoItemModel id: \(todoItemModel.id ?? 0)")
                       }catch let jsonErr{
                           print(jsonErr)
                      }
                
               }
               task.resume()
    }
    
    
    /////////////////////////////////////////////////
    
     func URLSessionGetAPI() {
        
        print("get API")
        
        // Create URL
        let url = URL(string: "https://jsonplaceholder.typicode.com/todos/1")
        guard let requestUrl = url else { fatalError() }

        // Create URL Request
        var request = URLRequest(url: requestUrl)

        // Specify HTTP Method to use
        request.httpMethod = "GET"

        // Send HTTP Request
       let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
          
               guard let data = data else { return }
               // Using parseJSON() function to convert data to Swift struct
               let todoItem = self.parseJSON(data: data)
                   
               // Read todo item title
               guard let todoItemModel = todoItem else { return }
               print("Todo item title = \(todoItemModel.title)")
        
        }
       task.resume()
        
    }
    func parseJSON(data: Data) -> ToDoResponseModel? {
        
        var returnValue: ToDoResponseModel?
        do {
            returnValue = try JSONDecoder().decode(ToDoResponseModel.self, from: data)
        } catch {
            print("Error took place\(error.localizedDescription).")
        }
        
        return returnValue
    }

    
    /////////////////////////////////////////////
    
    //Download API
    
    func downloadPDF(){

         guard let url = URL(string: "https://www.tutorialspoint.com/swift/swift_tutorial.pdf") else { return }
            
            let urlSession = URLSession(configuration: .default, delegate: self, delegateQueue: OperationQueue())
            
            let downloadTask = urlSession.downloadTask(with: url)
            downloadTask.resume()
        }

    @IBAction func pdfAction(_ sender: Any) {
        
        let pdfViewController = PDFViewController()
        pdfViewController.pdfURL = self.pdfURL
        present(pdfViewController, animated: false, completion: nil)
    }
    
     func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
           print("downloadLocation:", location)
           // create destination URL with the original pdf name
           guard let url = downloadTask.originalRequest?.url else { return }
           let documentsPath = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
           let destinationURL = documentsPath.appendingPathComponent(url.lastPathComponent)
           // delete original copy
           try? FileManager.default.removeItem(at: destinationURL)
           // copy from temp to Document
           do {
               try FileManager.default.copyItem(at: location, to: destinationURL)
               self.pdfURL = destinationURL
            
            
           } catch let error {
               print("Copy Error: \(error.localizedDescription)")
           }
       }
    


}


