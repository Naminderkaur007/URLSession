



import Foundation

struct docs : Codable{
    
    var id: String?
    var journal: String?
    var eissn: String?
    var publication_date: String?
    var article_type: String?
    var author_display: [String]?
    var abstract: [String]?
    var title_display: String?
    var score: Double?


    init(id: String?,journal: String?,eissn: String?,publication_date: String?,article_type: String?,author_display: [String]?,abstract: [String]?,title_display: String?,score: Double?){
     self.id = id
     self.journal = journal
     self.eissn = eissn
     self.publication_date = publication_date
     self.article_type = article_type
     self.author_display = author_display
     self.abstract = abstract
     self.title_display = title_display
     self.score = score
    }
    
}
