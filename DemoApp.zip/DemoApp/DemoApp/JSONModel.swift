


import Foundation

struct SuccessResult : Codable{
    var response : ResponseResult?
}

struct ResponseResult : Codable{
var docs: [docs]?
var numFound: Int?
var start: Int?
var maxScore: Double?
    
    
    init(docs : [docs]? ,numFound: Int?,start: Int?,maxScore: Double?){
        
        self.docs = docs
        self.numFound = numFound
        self.start = start
        self.maxScore = maxScore
       
       }

}
