//
//  PDFViewController.swift
//  AbcDemo
//
//  Created by MASH Virtual on 25/04/20.
//  Copyright © 2020 Vipin. All rights reserved.
//

import UIKit
import PDFKit


class PDFViewController: UIViewController {

    var pdfView = PDFView()
    var pdfURL: URL!


    override func viewDidLoad() {
        super.viewDidLoad()

        view.addSubview(pdfView)
        
        if let document = PDFDocument(url: pdfURL) {
            pdfView.document = document
            pdfView.displayMode = .singlePageContinuous
            pdfView.autoScales = true
        }
        
       

    }
    
    @IBAction func actionLogin(_ sender: Any) {
    }
    
    
    
    override func viewDidLayoutSubviews() {
          pdfView.frame = view.frame
      }
    
    
    
    
    
    
    
    
    
    

}
